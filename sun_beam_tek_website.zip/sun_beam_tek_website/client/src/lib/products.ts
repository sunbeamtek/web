export const products = [
  {
    id: 1,
    name: "Solar Panels",
    description: "High-efficiency monocrystalline and polycrystalline solar panels with 25-year warranty.",
    features: [
      "300W - 550W capacity",
      "Premium grade silicon",
      "Weather resistant",
      "25-year performance warranty",
    ],
    image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  },
  {
    id: 2,
    name: "Solar Inverters",
    description: "Advanced MPPT solar inverters for maximum power conversion efficiency.",
    features: [
      "Pure sine wave output",
      "3KW - 15KW capacity",
      "LCD display monitoring",
      "Built-in protection features",
    ],
    image: "https://images.unsplash.com/photo-1497440001374-f26997328c1b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  },
  {
    id: 3,
    name: "Solar Batteries",
    description: "Deep cycle batteries for reliable energy storage and backup power.",
    features: [
      "AGM & Lithium options",
      "100Ah - 400Ah capacity",
      "Long cycle life",
      "Maintenance-free design",
    ],
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  },
  {
    id: 4,
    name: "Solar Accessories",
    description: "Complete range of mounting systems, cables, and monitoring equipment.",
    features: [
      "Mounting structures",
      "DC/AC cables",
      "Monitoring systems",
      "Safety equipment",
    ],
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
  },
];
