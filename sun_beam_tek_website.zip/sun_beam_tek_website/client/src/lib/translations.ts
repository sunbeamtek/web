export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About",
      products: "Products",
      projects: "Projects",
      contact: "Contact",
    },
    hero: {
      title: {
        part1: "Power Your Future with ",
        part2: "Clean Solar Energy",
      },
      subtitle: "Leading solar energy solutions provider in Zafarwal, Narowal. Professional installation, premium quality panels, inverters, and batteries for residential and commercial properties.",
      getQuote: "Get Free Quote",
      whatsapp: "WhatsApp Chat",
    },
    about: {
      title: {
        part1: "Leading Solar Energy Solutions in ",
        part2: "Zafarwal",
      },
      description: "Sun Beam Tek is your trusted partner for comprehensive solar energy solutions in Zafarwal, District Narowal, Punjab, Pakistan. We specialize in high-quality solar panels, inverters, batteries, and accessories for both residential and commercial applications.",
      features: {
        installation: {
          title: "Expert Installation",
          description: "Professional installation by certified technicians",
        },
        quality: {
          title: "Premium Quality",
          description: "Top-grade solar equipment with warranties",
        },
        service: {
          title: "Local Service",
          description: "Serving Zafarwal and surrounding areas",
        },
        sustainable: {
          title: "Sustainable Future",
          description: "Clean energy for a better tomorrow",
        },
      },
      experience: "Years Experience",
    },
    products: {
      title: "Our Solar Products & Services",
      subtitle: "Comprehensive range of solar energy solutions designed to meet your power needs and budget requirements.",
      inquire: "Inquire Now",
    },
    whyChoose: {
      title: "Why Choose Sun Beam Tek?",
      subtitle: "We're committed to providing the best solar energy solutions with exceptional service and support.",
      installation: {
        title: "Professional Installation",
        description: "Expert technicians ensure proper installation and optimal system performance.",
      },
      quality: {
        title: "Quality Assurance",
        description: "Premium quality products with comprehensive warranties and after-sales support.",
      },
      support: {
        title: "24/7 Support",
        description: "Round-the-clock customer support and maintenance services for your peace of mind.",
      },
    },
    projects: {
      title: "Recent Solar Projects",
      subtitle: "Explore our successful solar installations across Zafarwal and surrounding areas.",
      residential: "Residential Installation",
      commercial: "Commercial Project",
      industrial: "Industrial Installation",
      rooftop: "Rooftop Installation",
      modern: "Modern Home Project",
      professional: "Professional Installation",
    },
    testimonials: {
      title: "What Our Customers Say",
      subtitle: "Read testimonials from satisfied customers who have made the switch to solar energy.",
    },
    contact: {
      title: "Get Your Free Solar Quote",
      subtitle: "Ready to make the switch to solar energy? Contact us today for a free consultation and quote.",
      form: {
        title: "Request a Quote",
        name: "Full Name",
        namePlaceholder: "Enter your full name",
        phone: "Phone Number",
        email: "Email Address",
        inquiryType: "Inquiry Type",
        selectInquiry: "Select inquiry type",
        installation: "Solar Installation",
        product: "Product Information",
        maintenance: "Maintenance Service",
        other: "Other",
        message: "Message",
        messagePlaceholder: "Tell us about your solar energy needs...",
        send: "Send Message",
        sending: "Sending...",
      },
      info: {
        title: "Contact Information",
        address: "Address",
        phone: "Phone",
        email: "Email",
        hours: "Business Hours",
      },
      quick: {
        title: "Quick Contact",
        whatsapp: "WhatsApp Chat",
        email: "Send Email",
      },
      location: {
        title: "Our Location",
      },
      success: {
        title: "Message Sent!",
        message: "Thank you for your inquiry. We will contact you soon.",
      },
      error: {
        title: "Error",
        required: "Please fill in all required fields.",
      },
    },
    footer: {
      description: "Your trusted partner for solar energy solutions in Zafarwal, Narowal, and surrounding areas.",
      quickLinks: "Quick Links",
      services: "Our Services",
      contactInfo: "Contact Info",
    },
  },
  ur: {
    nav: {
      home: "ہوم",
      about: "تعارف",
      products: "پروڈکٹس",
      projects: "پروجیکٹس",
      contact: "رابطہ",
    },
    hero: {
      title: {
        part1: "صاف شمسی توانائی کے ساتھ ",
        part2: "اپنے مستقبل کو طاقت دیں",
      },
      subtitle: "ظفروال، نارووال میں سولر انرجی کے حل کا سرکردہ فراہم کنندہ۔ رہائشی اور تجارتی پراپرٹیز کے لیے پیشہ ورانہ تنصیب، اعلیٰ معیار کے پینلز، انورٹرز اور بیٹریاں۔",
      getQuote: "مفت کوٹ حاصل کریں",
      whatsapp: "واٹس ایپ چیٹ",
    },
    about: {
      title: {
        part1: "ظفروال میں سولر انرجی کے ",
        part2: "بہترین حل",
      },
      description: "سن بیم ٹیک ظفروال، ضلع نارووال، پنجاب، پاکستان میں جامع سولر انرجی حل کا آپ کا قابل اعتماد شریک ہے۔ ہم رہائشی اور تجارتی دونوں استعمال کے لیے اعلیٰ معیار کے سولر پینلز، انورٹرز، بیٹریاں اور لوازمات میں مہارت رکھتے ہیں۔",
      features: {
        installation: {
          title: "ماہرانہ تنصیب",
          description: "تصدیق شدہ تکنیشنز کی طرف سے پیشہ ورانہ تنصیب",
        },
        quality: {
          title: "اعلیٰ معیار",
          description: "وارنٹی کے ساتھ اعلیٰ درجے کا سولر سامان",
        },
        service: {
          title: "مقامی خدمات",
          description: "ظفروال اور آس پاس کے علاقوں میں خدمات",
        },
        sustainable: {
          title: "پائیدار مستقبل",
          description: "بہتر کل کے لیے صاف توانائی",
        },
      },
      experience: "سال کا تجربہ",
    },
    products: {
      title: "ہماری سولر پروڈکٹس اور خدمات",
      subtitle: "آپ کی بجلی کی ضروریات اور بجٹ کے مطابق ڈیزائن کیے گئے سولر انرجی حل کی مکمل رینج۔",
      inquire: "ابھی پوچھیں",
    },
    whyChoose: {
      title: "سن بیم ٹیک کیوں چنیں؟",
      subtitle: "ہم بہترین سولر انرجی حل فراہم کرنے کے لیے متعہد ہیں۔",
      installation: {
        title: "پیشہ ورانہ تنصیب",
        description: "ماہر تکنیشنز مناسب تنصیب اور بہترین سسٹم کی کارکردگی کو یقینی بناتے ہیں۔",
      },
      quality: {
        title: "معیار کی یقین دہانی",
        description: "جامع وارنٹی اور بعد از فروخت سپورٹ کے ساتھ اعلیٰ معیار کی پروڈکٹس۔",
      },
      support: {
        title: "24/7 سپورٹ",
        description: "آپ کے ذہنی سکون کے لیے 24 گھنٹے کسٹمر سپورٹ اور مینٹیننس خدمات۔",
      },
    },
    projects: {
      title: "حالیہ سولر پروجیکٹس",
      subtitle: "ظفروال اور آس پاس کے علاقوں میں ہماری کامیاب سولر تنصیبات کو دیکھیں۔",
      residential: "رہائشی تنصیب",
      commercial: "تجارتی پروجیکٹ",
      industrial: "صنعتی تنصیب",
      rooftop: "چھت پر تنصیب",
      modern: "جدید گھر کا پروجیکٹ",
      professional: "پیشہ ورانہ تنصیب",
    },
    testimonials: {
      title: "ہمارے کسٹمرز کیا کہتے ہیں",
      subtitle: "مطمئن کسٹمرز کے تبصرے پڑھیں جنہوں نے سولر انرجی کا رخ کیا ہے۔",
    },
    contact: {
      title: "اپنا مفت سولر کوٹ حاصل کریں",
      subtitle: "سولر انرجی کی طرف رخ کرنے کے لیے تیار ہیں؟ آج ہی مفت مشاورت اور کوٹ کے لیے رابطہ کریں۔",
      form: {
        title: "کوٹ کی درخواست",
        name: "مکمل نام",
        namePlaceholder: "اپنا مکمل نام درج کریں",
        phone: "فون نمبر",
        email: "ای میل ایڈریس",
        inquiryType: "استفسار کی قسم",
        selectInquiry: "استفسار کی قسم منتخب کریں",
        installation: "سولر انسٹالیشن",
        product: "پروڈکٹ کی معلومات",
        maintenance: "مینٹیننس سروس",
        other: "دیگر",
        message: "پیغام",
        messagePlaceholder: "ہمیں اپنی سولر انرجی کی ضروریات کے بارے میں بتائیں...",
        send: "پیغام بھیجیں",
        sending: "بھیجا جا رہا ہے...",
      },
      info: {
        title: "رابطے کی معلومات",
        address: "پتہ",
        phone: "فون",
        email: "ای میل",
        hours: "کاروباری اوقات",
      },
      quick: {
        title: "فوری رابطہ",
        whatsapp: "واٹس ایپ چیٹ",
        email: "ای میل بھیجیں",
      },
      location: {
        title: "ہماری لوکیشن",
      },
      success: {
        title: "پیغام بھیج دیا گیا!",
        message: "آپ کے استفسار کا شکریہ۔ ہم جلد ہی آپ سے رابطہ کریں گے۔",
      },
      error: {
        title: "خرابی",
        required: "براہ کرم تمام لازمی فیلڈز بھریں۔",
      },
    },
    footer: {
      description: "ظفروال، نارووال اور آس پاس کے علاقوں میں سولر انرجی حل کا آپ کا قابل اعتماد شریک۔",
      quickLinks: "فوری لنکس",
      services: "ہماری خدمات",
      contactInfo: "رابطے کی معلومات",
    },
  },
  zh: {
    nav: {
      home: "主页",
      about: "关于我们",
      products: "产品",
      projects: "项目",
      contact: "联系我们",
    },
    hero: {
      title: {
        part1: "用清洁太阳能 ",
        part2: "为您的未来提供动力",
      },
      subtitle: "扎法瓦尔、纳罗瓦尔领先的太阳能解决方案提供商。为住宅和商业物业提供专业安装、优质面板、逆变器和电池。",
      getQuote: "获取免费报价",
      whatsapp: "WhatsApp聊天",
    },
    about: {
      title: {
        part1: "扎法瓦尔领先的 ",
        part2: "太阳能解决方案",
      },
      description: "Sun Beam Tek 是您在巴基斯坦旁遮普省纳罗瓦尔区扎法瓦尔的综合太阳能解决方案可信赖合作伙伴。我们专业从事住宅和商业应用的高质量太阳能电池板、逆变器、电池和配件。",
      features: {
        installation: {
          title: "专业安装",
          description: "经认证的技术人员进行专业安装",
        },
        quality: {
          title: "优质品质",
          description: "带保修的顶级太阳能设备",
        },
        service: {
          title: "本地服务",
          description: "为扎法瓦尔及周边地区服务",
        },
        sustainable: {
          title: "可持续发展",
          description: "清洁能源，创造更美好的明天",
        },
      },
      experience: "年经验",
    },
    products: {
      title: "我们的太阳能产品和服务",
      subtitle: "全面的太阳能解决方案，旨在满足您的电力需求和预算要求。",
      inquire: "立即咨询",
    },
    whyChoose: {
      title: "为什么选择Sun Beam Tek？",
      subtitle: "我们致力于提供最好的太阳能解决方案和卓越的服务支持。",
      installation: {
        title: "专业安装",
        description: "专业技术人员确保正确安装和最佳系统性能。",
      },
      quality: {
        title: "质量保证",
        description: "优质产品，提供全面保修和售后支持。",
      },
      support: {
        title: "24/7支持",
        description: "全天候客户支持和维护服务，让您安心无忧。",
      },
    },
    projects: {
      title: "最新太阳能项目",
      subtitle: "探索我们在扎法瓦尔及周边地区的成功太阳能安装项目。",
      residential: "住宅安装",
      commercial: "商业项目",
      industrial: "工业安装",
      rooftop: "屋顶安装",
      modern: "现代住宅项目",
      professional: "专业安装",
    },
    testimonials: {
      title: "客户评价",
      subtitle: "阅读已转向太阳能的满意客户的推荐。",
    },
    contact: {
      title: "获取免费太阳能报价",
      subtitle: "准备转向太阳能？今天就联系我们进行免费咨询和报价。",
      form: {
        title: "申请报价",
        name: "全名",
        namePlaceholder: "输入您的全名",
        phone: "电话号码",
        email: "邮箱地址",
        inquiryType: "咨询类型",
        selectInquiry: "选择咨询类型",
        installation: "太阳能安装",
        product: "产品信息",
        maintenance: "维护服务",
        other: "其他",
        message: "消息",
        messagePlaceholder: "告诉我们您的太阳能需求...",
        send: "发送消息",
        sending: "发送中...",
      },
      info: {
        title: "联系信息",
        address: "地址",
        phone: "电话",
        email: "邮箱",
        hours: "营业时间",
      },
      quick: {
        title: "快速联系",
        whatsapp: "WhatsApp聊天",
        email: "发送邮件",
      },
      location: {
        title: "我们的位置",
      },
      success: {
        title: "消息已发送！",
        message: "感谢您的咨询。我们将很快与您联系。",
      },
      error: {
        title: "错误",
        required: "请填写所有必填字段。",
      },
    },
    footer: {
      description: "您在扎法瓦尔、纳罗瓦尔及周边地区太阳能解决方案的可信赖合作伙伴。",
      quickLinks: "快速链接",
      services: "我们的服务",
      contactInfo: "联系信息",
    },
  },
  hi: {
    nav: {
      home: "होम",
      about: "हमारे बारे में",
      products: "उत्पाद",
      projects: "परियोजनाएं",
      contact: "संपर्क",
    },
    hero: {
      title: {
        part1: "स्वच्छ सौर ऊर्जा के साथ ",
        part2: "अपने भविष्य को शक्ति दें",
      },
      subtitle: "ज़फ़रवाल, नारोवाल में अग्रणी सौर ऊर्जा समाधान प्रदाता। आवासीय और व्यावसायिक संपत्तियों के लिए पेशेवर स्थापना, प्रीमियम गुणवत्ता पैनल, इनवर्टर और बैटरी।",
      getQuote: "मुफ्त कोटेशन प्राप्त करें",
      whatsapp: "व्हाट्सऐप चैट",
    },
    about: {
      title: {
        part1: "ज़फ़रवाल में अग्रणी ",
        part2: "सौर ऊर्जा समाधान",
      },
      description: "सन बीम टेक ज़फ़रवाल, जिला नारोवाल, पंजाब, पाकिस्तान में व्यापक सौर ऊर्जा समाधान के लिए आपका विश्वसनीय साझेदार है। हम आवासीय और व्यावसायिक दोनों अनुप्रयोगों के लिए उच्च गुणवत्ता वाले सौर पैनल, इनवर्टर, बैटरी और सहायक उपकरण में विशेषज्ञता रखते हैं।",
      features: {
        installation: {
          title: "विशेषज्ञ स्थापना",
          description: "प्रमाणित तकनीशियनों द्वारा पेशेवर स्थापना",
        },
        quality: {
          title: "प्रीमियम गुणवत्ता",
          description: "वारंटी के साथ शीर्ष-ग्रेड सौर उपकरण",
        },
        service: {
          title: "स्थानीय सेवा",
          description: "ज़फ़रवाल और आसपास के क्षेत्रों में सेवा",
        },
        sustainable: {
          title: "स्थायी भविष्य",
          description: "बेहतर कल के लिए स्वच्छ ऊर्जा",
        },
      },
      experience: "वर्षों का अनुभव",
    },
    products: {
      title: "हमारे सौर उत्पाद और सेवाएं",
      subtitle: "आपकी विद्युत आवश्यकताओं और बजट आवश्यकताओं को पूरा करने के लिए डिज़ाइन किए गए सौर ऊर्जा समाधान की व्यापक श्रेणी।",
      inquire: "अभी पूछताछ करें",
    },
    whyChoose: {
      title: "सन बीम टेक क्यों चुनें?",
      subtitle: "हम असाधारण सेवा और समर्थन के साथ सर्वोत्तम सौर ऊर्जा समाधान प्रदान करने के लिए प्रतिबद्ध हैं।",
      installation: {
        title: "पेशेवर स्थापना",
        description: "विशेषज्ञ तकनीशियन उचित स्थापना और इष्टतम सिस्टम प्रदर्शन सुनिश्चित करते हैं।",
      },
      quality: {
        title: "गुणवत्ता आश्वासन",
        description: "व्यापक वारंटी और बिक्री के बाद समर्थन के साथ प्रीमियम गुणवत्ता उत्पाद।",
      },
      support: {
        title: "24/7 समर्थन",
        description: "आपकी मानसिक शांति के लिए चौबीसों घंटे ग्राहक सहायता और रखरखाव सेवाएं।",
      },
    },
    projects: {
      title: "हाल की सौर परियोजनाएं",
      subtitle: "ज़फ़रवाल और आसपास के क्षेत्रों में हमारी सफल सौर स्थापनाओं का अन्वेषण करें।",
      residential: "आवासीय स्थापना",
      commercial: "व्यावसायिक परियोजना",
      industrial: "औद्योगिक स्थापना",
      rooftop: "छत पर स्थापना",
      modern: "आधुनिक गृह परियोजना",
      professional: "पेशेवर स्थापना",
    },
    testimonials: {
      title: "हमारे ग्राहक क्या कहते हैं",
      subtitle: "संतुष्ट ग्राहकों के प्रशंसापत्र पढ़ें जिन्होंने सौर ऊर्जा का रुख किया है।",
    },
    contact: {
      title: "अपना मुफ्त सौर कोटेशन प्राप्त करें",
      subtitle: "सौर ऊर्जा की ओर रुख करने के लिए तैयार हैं? आज ही मुफ्त परामर्श और कोटेशन के लिए हमसे संपर्क करें।",
      form: {
        title: "कोटेशन का अनुरोध",
        name: "पूरा नाम",
        namePlaceholder: "अपना पूरा नाम दर्ज करें",
        phone: "फ़ोन नंबर",
        email: "ईमेल पता",
        inquiryType: "पूछताछ का प्रकार",
        selectInquiry: "पूछताछ का प्रकार चुनें",
        installation: "सौर स्थापना",
        product: "उत्पाद जानकारी",
        maintenance: "रखरखाव सेवा",
        other: "अन्य",
        message: "संदेश",
        messagePlaceholder: "हमें अपनी सौर ऊर्जा आवश्यकताओं के बारे में बताएं...",
        send: "संदेश भेजें",
        sending: "भेजा जा रहा है...",
      },
      info: {
        title: "संपर्क जानकारी",
        address: "पता",
        phone: "फ़ोन",
        email: "ईमेल",
        hours: "व्यावसायिक घंटे",
      },
      quick: {
        title: "त्वरित संपर्क",
        whatsapp: "व्हाट्सऐप चैट",
        email: "ईमेल भेजें",
      },
      location: {
        title: "हमारा स्थान",
      },
      success: {
        title: "संदेश भेजा गया!",
        message: "आपकी पूछताछ के लिए धन्यवाद। हम जल्द ही आपसे संपर्क करेंगे।",
      },
      error: {
        title: "त्रुटि",
        required: "कृपया सभी आवश्यक फ़ील्ड भरें।",
      },
    },
    footer: {
      description: "ज़फ़रवाल, नारोवाल और आसपास के क्षेत्रों में सौर ऊर्जा समाधान के लिए आपका विश्वसनीय साझेदार।",
      quickLinks: "त्वरित लिंक",
      services: "हमारी सेवाएं",
      contactInfo: "संपर्क जानकारी",
    },
  },
};
