import { Button } from "@/components/ui/button";
import { Calculator, MessageCircle } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function HeroSection() {
  const { t } = useLanguage();

  const handleGetQuote = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center bg-gradient-to-br from-green-50 to-blue-50">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080"
          alt="Solar panel installation field"
          className="w-full h-full object-cover opacity-20"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
          {t("hero.title.part1")}
          <span className="text-green-600 block md:inline">
            {t("hero.title.part2")}
          </span>
        </h1>
        <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          {t("hero.subtitle")}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={handleGetQuote}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg"
          >
            <Calculator className="w-5 h-5 mr-2" />
            {t("hero.getQuote")}
          </Button>
          <Button 
            asChild
            variant="outline"
            className="border-green-600 text-green-600 hover:bg-green-600 hover:text-white px-8 py-6 text-lg"
          >
            <a href="https://wa.me/923077575435" target="_blank" rel="noopener noreferrer">
              <MessageCircle className="w-5 h-5 mr-2" />
              {t("hero.whatsapp")}
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
