import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function ContactSection() {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    inquiryType: "",
    message: "",
  });

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t("contact.success.title"),
        description: t("contact.success.message"),
      });
      setFormData({
        name: "",
        phone: "",
        email: "",
        inquiryType: "",
        message: "",
      });
    },
    onError: (error) => {
      toast({
        title: t("contact.error.title"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.inquiryType) {
      toast({
        title: t("contact.error.title"),
        description: t("contact.error.required"),
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t("contact.title")}
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            {t("contact.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl">{t("contact.form.title")}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">{t("contact.form.name")} *</Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    placeholder={t("contact.form.namePlaceholder")}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone">{t("contact.form.phone")} *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    placeholder="+92 XXX XXXXXXX"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">{t("contact.form.email")}</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    placeholder="your@email.com"
                  />
                </div>

                <div>
                  <Label htmlFor="inquiryType">{t("contact.form.inquiryType")} *</Label>
                  <Select value={formData.inquiryType} onValueChange={(value) => handleInputChange("inquiryType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder={t("contact.form.selectInquiry")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="installation">{t("contact.form.installation")}</SelectItem>
                      <SelectItem value="product">{t("contact.form.product")}</SelectItem>
                      <SelectItem value="maintenance">{t("contact.form.maintenance")}</SelectItem>
                      <SelectItem value="other">{t("contact.form.other")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="message">{t("contact.form.message")}</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleInputChange("message", e.target.value)}
                    placeholder={t("contact.form.messagePlaceholder")}
                    rows={4}
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-green-600 hover:bg-green-700"
                  disabled={contactMutation.isPending}
                >
                  {contactMutation.isPending ? t("contact.form.sending") : t("contact.form.send")}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">{t("contact.info.title")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="text-green-600 h-6 w-6 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{t("contact.info.address")}</h4>
                    <p className="text-gray-600">
                      Zafarwal, District Narowal<br />
                      Punjab, Pakistan
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="text-green-600 h-6 w-6 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{t("contact.info.phone")}</h4>
                    <p className="text-gray-600">+92 307 7575435</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Mail className="text-green-600 h-6 w-6 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{t("contact.info.email")}</h4>
                    <p className="text-gray-600">sunbeamtek@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Clock className="text-green-600 h-6 w-6 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{t("contact.info.hours")}</h4>
                    <p className="text-gray-600">
                      Mon - Sat: 9:00 AM - 6:00 PM<br />
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Contact */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">{t("contact.quick.title")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  asChild
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <a href="https://wa.me/923077575435" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="w-5 h-5 mr-2" />
                    {t("contact.quick.whatsapp")}
                  </a>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white"
                >
                  <a href="mailto:sunbeamtek@gmail.com">
                    <Mail className="w-5 h-5 mr-2" />
                    {t("contact.quick.email")}
                  </a>
                </Button>
              </CardContent>
            </Card>

            {/* Google Maps */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">{t("contact.location.title")}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-green-600 mx-auto mb-2" />
                    <p className="text-gray-600">
                      Sun Beam Tek<br />
                      Zafarwal, Narowal, Punjab
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
