import { CheckCircle } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function AboutSection() {
  const { t } = useLanguage();

  const features = [
    {
      key: "installation",
      title: t("about.features.installation.title"),
      description: t("about.features.installation.description"),
    },
    {
      key: "quality",
      title: t("about.features.quality.title"),
      description: t("about.features.quality.description"),
    },
    {
      key: "service",
      title: t("about.features.service.title"),
      description: t("about.features.service.description"),
    },
    {
      key: "sustainable",
      title: t("about.features.sustainable.title"),
      description: t("about.features.sustainable.description"),
    },
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              {t("about.title.part1")}
              <span className="text-green-600">{t("about.title.part2")}</span>
            </h2>
            <p className="text-gray-600 mb-6 text-lg">
              {t("about.description")}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature) => (
                <div key={feature.key} className="flex items-start space-x-3">
                  <CheckCircle className="text-green-600 h-6 w-6 mt-1 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1559302504-64aae6ca6b6d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
              alt="Renewable energy team working on solar installation"
              className="rounded-2xl shadow-2xl w-full h-auto"
            />
            <div className="absolute -bottom-6 -right-6 bg-green-600 text-white p-6 rounded-2xl shadow-lg">
              <div className="text-center">
                <div className="text-3xl font-bold">5+</div>
                <div className="text-sm">{t("about.experience")}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
