import { useLanguage } from "@/hooks/use-language";

export default function ProjectsSection() {
  const { t } = useLanguage();

  const projects = [
    {
      id: 1,
      title: t("projects.residential"),
      capacity: "15kW Solar System",
      image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
    {
      id: 2,
      title: t("projects.commercial"),
      capacity: "50kW Solar System",
      image: "https://images.unsplash.com/photo-1497440001374-f26997328c1b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
    {
      id: 3,
      title: t("projects.industrial"),
      capacity: "100kW Solar System",
      image: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
    {
      id: 4,
      title: t("projects.rooftop"),
      capacity: "25kW Solar System",
      image: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
    {
      id: 5,
      title: t("projects.modern"),
      capacity: "20kW Solar System",
      image: "https://images.unsplash.com/photo-1559302504-64aae6ca6b6d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
    {
      id: 6,
      title: t("projects.professional"),
      capacity: "Expert Team at Work",
      image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
    },
  ];

  return (
    <section id="projects" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t("projects.title")}
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            {t("projects.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div key={project.id} className="relative overflow-hidden rounded-2xl shadow-lg group">
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="font-semibold text-lg">{project.title}</h3>
                <p className="text-sm opacity-90">{project.capacity}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
